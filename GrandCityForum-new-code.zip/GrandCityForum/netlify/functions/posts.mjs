import { getStore } from "@netlify/blobs";
const store = () => getStore({ name: "grand-city-forum", consistency: "strong" });
const reply = (data,status=200) => new Response(JSON.stringify(data),{status,headers:{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"}});
export default async (req) => {
 try {
  const db=store();
  if(req.method==="GET"){
   const {blobs}=await db.list({prefix:"posts/"});
   const posts=(await Promise.all(blobs.map(x=>db.get(x.key,{type:"json",consistency:"strong"})))).filter(Boolean);
   posts.sort((a,b)=>b.createdAt-a.createdAt);
   return reply({posts:posts.slice(0,100)});
  }
  if(req.method==="POST"){
   const x=await req.json();
   const post={author:String(x.author||"").trim().slice(0,40),category:String(x.category||"General").slice(0,50),title:String(x.title||"").trim().slice(0,100),body:String(x.body||"").trim().slice(0,5000),createdAt:Date.now()};
   if(!post.author||!post.title||!post.body)return reply({error:"Name, title and message are required."},400);
   await db.setJSON("posts/"+crypto.randomUUID(),post);
   return reply({ok:true},201);
  }
  return reply({error:"Method not allowed"},405);
 } catch(e){console.error(e);return reply({error:"Server error. Check Netlify function deployment."},500)}
};
export const config={path:"/.netlify/functions/posts"};
